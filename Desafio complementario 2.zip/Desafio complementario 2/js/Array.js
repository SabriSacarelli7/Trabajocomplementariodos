let productos = [
    {nombre: "Blusa", precio: 1500, cant: 2},
    {nombre: "Jeans", precio: 5000, cant: 2},
    {nombre: "Campera", precio: 3000, cant: 1}
]

console.log(productos)

let acumulador = 0;

for(let productoEnArray of productos) {
    acumulador += productoEnArray.precio * productoEnArray.cant
}

console.log(acumulador)